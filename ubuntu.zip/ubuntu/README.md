# Magento 2 Automatized Server Configurator


This script installs the Magento and its server environment. It installs **Nginx**, **PHP7**, **MySQL**, **Postfix**, **Composer**, **Magento 2**, **Magento sample data** and all
required packages and dependencies with **Vhost configuration**.

Pre-requirements: Ubuntu 18.04 with Internet connection.

To install Magento, first fill out the install.ini file then run the command "bash install.sh"

**Add this Entry in local hosts file**
127.0.0.1       [domain]

## Guide

* Get an Ubuntu 18.04
* Update it: `sudo apt-get update`
* Install git: `sudo apt-get install git`
* Set your user names and passwords: `nano install.ini` or `gedit install.ini`
* Run the installer: `sudo bash install.sh`
* Now, you have an installed **Magento 2** prepared to development

## After Installation

The installation process created the Magento Linux User automatically, so you can login as Magento and use Magento's commands:
* `cd /var/www/[domain]/webroot`
* `su magento`
* `php bin/magento`

If you have any permission issues use the following commands:
* `cd /var/www/[domain]/webroot`
* `chown -R :www-data .`
* `find . -type d -exec chmod 770 {} \;`
* `find . -type f -exec chmod 660 {} \;`
* `chmod u+x bin/magento`

## Pending / TODO

* Adding Varnish Install script & support
* Adding ElasticSearch Install script & support

