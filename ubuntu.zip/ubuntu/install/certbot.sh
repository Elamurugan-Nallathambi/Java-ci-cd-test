#!/usr/bin/env bash

apt-get update -y
apt-get install python-minimal -y

apt-get install software-properties-common  -y

add-apt-repository ppa:certbot/certbot  -y
apt-get update -y

apt-get install certbot   -y
apt-get install letsencrypt -y


# Generate default ssl based on openssl
openssl req -x509 -nodes -days 365 -newkey rsa:2048 -keyout config/ssl/ssl.key -out config/ssl/ssl.crt -config config/ssl/ssl.cnf

sudo mkdir /etc/nginx/ssl
sudo chown -R root:root /etc/nginx/ssl
sudo chmod -R 600 /etc/nginx/ssl

# cp config/ssl/ssl.key /etc/ssl/certs/mvp-wv-dev.eenetworks.net.crt
sudo cp config/ssl/ssl.crt /etc/nginx/ssl/wildcard.eenetworks.crt
sudo cp config/ssl/ssl.key /etc/nginx/ssl/wildcard.eenetworks.key

