#!/usr/bin/env bash

apt-get update -y
apt-get install python-minimal -y

apt-get install software-properties-common  -y

add-apt-repository ppa:certbot/certbot  -y
apt-get update -y

apt-get install certbot   -y
apt-get install letsencrypt -y


# Generate default ssl based on openssl
openssl req  -new -x509 -nodes -days 3650 -newkey rsa:4096 -keyout config/ssl/ssl.key -out config/ssl/ssl.crt -config config/ssl/ssl.cnf

mkdir -p /etc/nginx/ssl
chown -R root:root /etc/nginx/ssl
chmod -R 600 /etc/nginx/ssl

# cp config/ssl/ssl.key /etc/ssl/certs/mvp-wv-dev.eenetworks.net.crt
cp config/ssl/ssl.crt /etc/nginx/ssl/wildcard.eenetworks.crt
cp config/ssl/ssl.key /etc/nginx/ssl/wildcard.eenetworks.key


systemctl stop nginx.service
systemctl start nginx.service