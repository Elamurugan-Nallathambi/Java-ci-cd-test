#!/usr/bin/env bash

apt-get update -y && apt-get upgrade -y

apt-get -y install varnish 

apt-get -y install unzip gettext bash

nano /lib/systemd/system/varnish.service

systemctl daemon-reload
service varnish restart
systemctl restart php7.2-fpm