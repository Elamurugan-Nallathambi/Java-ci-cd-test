#!/usr/bin/env bash

if [ $1 ] && [ $2 ] && [ $3 ] && [ $4 ];
    then
        adduser $3 --gecos "Magento System,0,0,0" --disabled-password
        echo "$3:$4" | chpasswd
        usermod -g www-data $3

        SITE=/etc/nginx/sites-available/$2
        cp config/nginx-site $SITE

        mkdir /var/www/$2
        mkdir /var/www/$2/webroot
        mkdir /var/www/$2/log

        echo "Download Magento $1 release"

        cd /var/www
        rm -rf /var/www/$2/webroot/*
        rm -rf /var/www/$2/webroot/.*

        cd /var/www/$2/webroot
        chown -R :www-data .
        find . -type d -exec chmod 770 {} \;
        find . -type f -exec chmod 660 {} \;
        chmod u+x bin/magento


        sed -i -e "s/mywebshop.com/$2/g" $SITE
        ln -s /etc/nginx/sites-available/$2 /etc/nginx/sites-enabled/

        service nginx reload
        systemctl restart nginx.service
    else
        echo ""
        echo "Missing parameters.";
        echo "1st parameter is magento release";
        echo "2nd parameter is magento folder name what is same as the domain address";
        echo "3rd parameter is magento linux user (it will create it)";
        echo "4th parameter is magento linux password (it will create it)";
        echo "Try this: magento-prepare.sh 2.0.7 [domain] magento magento";
        echo "";
fi;
