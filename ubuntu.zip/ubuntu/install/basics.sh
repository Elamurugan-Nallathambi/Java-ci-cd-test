#!/usr/bin/env bash

apt-get install ntp -y
apt-get update -y && apt-get upgrade -y
apt-get install unzip  -y
apt-get install git curl vim -y
