#!/usr/bin/env bash

apt-get install \
    nginx \
    --yes

service nginx restart

systemctl stop nginx.service
systemctl start nginx.service
systemctl enable nginx.service