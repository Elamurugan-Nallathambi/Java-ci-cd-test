#!/usr/bin/env bash

apt-get update -y && apt-get upgrade -y

apt-get install -y rabbitmq-server

rabbitmq-plugins enable rabbitmq_management
service rabbitmq-server stop
rabbitmq-server -detached