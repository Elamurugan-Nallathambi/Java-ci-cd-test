#!/usr/bin/env bash

cd /var/www/$1/webroot
git clone https://github.com/EmersonEcologics/wellevate-m2-magento.git .
git fetch
git checkout develop

#Install M2 dependencies
composer install

# cp default env and adjust db Config in env
cp /var/www/html/app/etc/env.php.redis.local /var/www/html/app/etc/env.php

# import DB
mysql  -hdb -umagento -pmagento magento < /var/www/html/app/init/db.sql

#Set Base URL's as per environment choice
php bin/magento setup:store-config:set --base-url-secure="https://app.wellevate2.test/"
php bin/magento setup:store-config:set --base-url="https://app.wellevate2.test/"

#Configure and setup Magento
bin/magento setup:upgrade
bin/magento deploy:mode:set production

#In case of exceptions may need to check with redis, varnish, rabbitmq service and availabiltiy or memory Availability  or Magento file permissions
# redis-cli flushall
# rm -Rf generated/* pub/static/frontend/* pub/static/adminhtml/* var/view_preprocessed/*
# php -d memory_limit=2048M bin/magento cache:flush
# php -d memory_limit=2048M bin/magento setup:upgrade
# php -d memory_limit=2048M bin/magento setup:di:compile
# php -d memory_limit=2048M bin/magento setup:static-content:deploy --theme Magento/backend --language en_US -f
# php bin/magento cache:enable
# find * -type d -print0 | xargs -0 chmod 0755
# find . -type f ! -path "./bin/*" -print0 | xargs -0 chmod 0644