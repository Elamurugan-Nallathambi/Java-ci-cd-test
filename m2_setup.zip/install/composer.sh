#!/usr/bin/env bash

curl -sS https://getcomposer.org/installer | php;
mv composer.phar /usr/bin/composer
