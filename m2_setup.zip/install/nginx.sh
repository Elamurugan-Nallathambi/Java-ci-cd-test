#!/usr/bin/env bash

sudo apt-get install \
    nginx \
    --yes

sudo service nginx restart

sudo systemctl stop nginx.service
sudo systemctl start nginx.service
sudo systemctl enable nginx.service