#!/usr/bin/env bash

sudo apt update && sudo apt upgrade
sudo apt install unzip

apt-get install \
    git \
    curl \
    vim \
    --yes
